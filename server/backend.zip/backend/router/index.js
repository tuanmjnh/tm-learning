"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const routes_1 = __importDefault(require("../controllers/routes"));
const users_1 = __importDefault(require("../controllers/users"));
const settings_1 = __importDefault(require("../controllers/users/settings"));
const roles_1 = __importDefault(require("../controllers/roles"));
const auth_1 = __importDefault(require("../controllers/auth"));
const types_1 = __importDefault(require("../controllers/types"));
const file_manager_1 = __importDefault(require("../controllers/file-manager"));
const categories_1 = __importDefault(require("../controllers/categories"));
const questions_1 = __importDefault(require("../controllers/questions"));
const exercises_1 = __importDefault(require("../controllers/exercises"));
const exams_1 = __importDefault(require("../controllers/exercises/exams"));
const news_1 = __importDefault(require("../controllers/news"));
const products_1 = __importDefault(require("../controllers/products"));
const imports_1 = __importDefault(require("../controllers/warehouse/imports"));
const exports_1 = __importDefault(require("../controllers/warehouse/exports"));
const reports_1 = __importDefault(require("../controllers/warehouse/reports"));
const test_1 = __importDefault(require("../controllers/test"));
class Routes {
    constructor() {
        this.router = express_1.Router();
        this.mapRouter = (controller) => {
            const route = this.router.route(`/${controller.path}`);
            if (controller.get)
                route.get(controller.get);
            if (controller.post)
                route.post(controller.post);
            if (controller.put)
                route.put(controller.put);
            if (controller.patch)
                route.patch(controller.patch);
            if (controller.delete)
                route.delete(controller.delete);
            // Extras
            if (controller.find)
                this.router.route(`/${controller.path}/find`).get(controller.find);
            if (controller.exist)
                this.router.route(`/${controller.path}/exist`).get(controller.exist);
            if (controller.getKey)
                this.router.route(`/${controller.path}/get-key`).get(controller.getKey);
            if (controller.getMeta)
                this.router.route(`/${controller.path}/get-meta`).get(controller.getMeta);
            if (controller.import)
                this.router.route(`/${controller.path}/import`).post(controller.import);
            if (controller.updateOrder)
                this.router.route(`/${controller.path}/update-order`).put(controller.updateOrder);
            // Extras users
            if (controller.verified)
                this.router.route(`/${controller.path}/verified`).post(controller.verified);
            if (controller.resetPassword)
                this.router.route(`/${controller.path}/reset-password`).post(controller.resetPassword);
            if (controller.changePassword)
                this.router.route(`${controller.path}/change-password`).post(controller.changePassword);
        };
        this.mapRouter(routes_1.default);
        this.mapRouter(users_1.default);
        this.router.route(`/${users_1.default.path}/finds`).post(users_1.default.finds);
        this.mapRouter(settings_1.default);
        this.mapRouter(roles_1.default);
        this.mapRouter(auth_1.default);
        this.mapRouter(types_1.default);
        this.mapRouter(categories_1.default);
        this.mapRouter(questions_1.default);
        this.mapRouter(exercises_1.default);
        this.mapRouter(exams_1.default);
        this.router.route(`/${exams_1.default.path}/get-exercies`).get(exams_1.default.getExercies);
        this.router.route(`/${exams_1.default.path}/get-questions`).get(exams_1.default.getQuestions);
        this.router.route(`/${exams_1.default.path}/get-report`).get(exams_1.default.getReport);
        this.mapRouter(news_1.default);
        this.mapRouter(products_1.default);
        this.mapRouter(imports_1.default);
        this.mapRouter(exports_1.default);
        // FileManager Controller
        this.mapRouter(file_manager_1.default);
        this.router
            .route(`/${file_manager_1.default.path}/directories`)
            .get(file_manager_1.default.getDirectories);
        this.router.route(`/${file_manager_1.default.path}/files`).get(file_manager_1.default.getFiles);
        // ProductReports Controller
        this.router.route(`/${reports_1.default.path}`).get(reports_1.default.date);
        this.router
            .route(`/${reports_1.default.path}/weekly`)
            .get(reports_1.default.weekly);
        this.router.route(`${reports_1.default.path}/month`).get(reports_1.default.month);
        this.router
            .route(`/${reports_1.default.path}/quarter`)
            .get(reports_1.default.quarter);
        this.router.route(`${reports_1.default.path}/year`).get(reports_1.default.year);
        this.router
            .route(`/${reports_1.default.path}/five-year`)
            .get(reports_1.default.fiveYear);
        // Test Controller
        this.mapRouter(test_1.default);
    }
}
exports.Routes = Routes;
exports.default = Routes;
//# sourceMappingURL=index.js.map