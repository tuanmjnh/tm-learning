"use strict";
// const mongodb = require('mongodb');
// // mongodb initialize
// module.exports.initialize = function() {
//   mongodb.MongoClient.connect(
//     // process.env.MONGODB,
//     process.env.MONGODB_ATLAS,
//     {
//       useNewUrlParser: true
//     }
//   ).then(() => {
//     console.log('Database connection is successful')
//   }).catch(e => { console.log(`Error when connecting to the database ${e}`) })
// }
//# sourceMappingURL=mongodb.js.map