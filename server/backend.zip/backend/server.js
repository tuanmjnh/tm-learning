"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("./utils/prototypes");
require("./config");
// Appliction
// import http from "http"
const app_1 = __importDefault(require("./services/app"));
// var server=http.createServer(function(req,res){
//   res.end('test');
// });
const server = new app_1.default();
server.start(process.env.PORT || 8001);
// const app = new Appliction();
// const server = http.createServer(app.start(process.env.PORT || 8001));
// -----------------------------------------------------------------------------
// When SIGINT is received (i.e. Ctrl-C is pressed), shutdown services
// -----------------------------------------------------------------------------
// process.on('SIGINT', () => {
//   console.log('SIGINT received ...');
//   console.log('Shutting down the server');
//   server.close(() => {
//     console.log('Server has been shutdown');
//     console.log('Exiting process ...');
//     process.exit(0);
//   });
// });
//# sourceMappingURL=server.js.map