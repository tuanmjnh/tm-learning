"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    startAt: { type: Date, required: true },
    endAt: { type: Date },
    startBy: { type: String, required: true },
    startIp: { type: String, required: true },
    // userAgent: { type: String, required: true },
    exercise: { type: String, required: true },
    totalQuestion: { type: Number, default: 0 },
    totalCorrect: { type: Number, default: 0 },
    totalWrong: { type: Number, default: 0 },
    questions: { type: Array, default: [] },
    result: { type: Number, default: 0 },
    flag: { type: Number, default: 1 },
});
exports.MExams = mongoose_1.model('exams', schema);
exports.default = exports.MExams;
//# sourceMappingURL=exams.js.map