"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    type: { type: Number, default: 1 },
    name: { type: String, required: true },
    users: { type: Array, required: true },
    questions: { type: Array, required: true },
    startAt: { type: Date, required: true },
    endAt: { type: Date, required: true },
    numberTest: { type: Number, default: 1 },
    minutes: { type: Number, default: 60 },
    mixQuestion: { type: Number, default: 1 },
    mixAnswer: { type: Number, default: 1 },
    eligible: { type: Number, required: true },
    totalQuestion: { type: Number, required: true },
    desc: { type: String, default: null },
    tags: { type: Array, default: null },
    order: { type: Number, default: 1 },
    flag: { type: Number, default: 1 },
    createdAt: { type: Date, default: new Date() },
    createdBy: { type: String, required: true },
    createdIp: { type: String, required: true },
});
exports.MExercises = mongoose_1.model('exercises', schema);
schema.index({ name: 'text' });
exports.default = exports.MExercises;
//# sourceMappingURL=index.js.map