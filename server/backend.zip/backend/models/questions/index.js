"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    key: { type: String, required: true },
    categories: { type: String, default: null },
    kind: { type: Number, required: true },
    level: { type: Number, required: true },
    point: { type: Number, default: 1 },
    content: { type: String, required: true },
    answers: { type: Array, required: true },
    correct: { type: Array, required: true },
    tags: { type: Array, default: null },
    order: { type: Number, default: 1 },
    flag: { type: Number, default: 1 },
});
exports.MQuestion = mongoose_1.model('questions', schema);
exports.default = exports.MQuestion;
//# sourceMappingURL=index.js.map