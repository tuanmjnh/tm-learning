"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
const logger_1 = __importDefault(require("../../services/logger"));
const pagination_1 = __importDefault(require("../../utils/pagination"));
const mongoose_1 = require("mongoose");
const request_1 = require("../../utils/request");
const exams_1 = require("../../models/exercises/exams");
const exercises_1 = require("../../models/exercises");
const questions_1 = require("../../models/questions");
const users_1 = require("../../models/users");
class ExamsController {
    constructor() {
        this.path = 'exams';
        this.get = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                const conditions = {};
                if (req.query.filter)
                    conditions.$text = { $search: req.query.filter };
                if (req.query.flag)
                    conditions.flag = parseInt(req.query.flag.toString());
                conditions.$expr = {
                    $and: [{ $eq: ['$exercise', req.query.exercise] }, { $eq: ['$startBy', req.verify._id] }],
                };
                const countDocuments = yield exams_1.MExams.where(conditions).countDocuments();
                const qry = exams_1.MExams.aggregate([
                    { $match: conditions },
                    {
                        $sort: {
                            [req.query.sortBy || 'startAt']: -1,
                        },
                    },
                ]);
                const page = parseInt(req.query.page);
                const rowsPerPage = parseInt(req.query.rowsPerPage);
                if (page && rowsPerPage)
                    qry.skip((page - 1) * rowsPerPage).limit(rowsPerPage);
                const rs = yield qry.exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.find = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (req.query._id) {
                    if (mongoose_1.Types.ObjectId.isValid(req.query._id)) {
                        exams_1.MExams.findById(req.query._id, (e, rs) => {
                            if (e)
                                return res.status(500).send(e);
                            return res.status(200).json(rs);
                        });
                    }
                    else {
                        return res.status(500).send('invalid');
                    }
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.exist = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                exams_1.MExams.findOne(req.query, (e, rs) => {
                    if (e)
                        return res.status(200).json(null);
                    return res.status(200).json(rs);
                });
            }
            catch (e) {
                return res.status(200).json(null);
            }
        });
        this.getAttr = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                exams_1.MExams.distinct(req.query.key ? 'attr.key' : 'attr.value', null, (e, rs) => {
                    if (e)
                        return res.status(500).send(e);
                    if (req.query.filter)
                        rs = rs.filter((x) => new RegExp(req.query.filter, 'i').test(x));
                    const countDocuments = rs.length;
                    if (req.query.page && req.query.rowsPerPage)
                        rs = pagination_1.default.get(rs, parseInt(req.query.page), parseInt(req.query.rowsPerPage));
                    return res.status(200).json({ rowsNumber: countDocuments, data: rs });
                });
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.getExercies = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                const conditions = {};
                if (req.query.filter)
                    conditions.$text = { $search: req.query.filter };
                conditions.flag = 1;
                const dateNow = moment_1.default().toISOString();
                conditions.startAt = { $lt: dateNow };
                conditions.endAt = { $gte: dateNow };
                conditions.users = { $in: req.verify.code };
                const countDocuments = yield exercises_1.MExercises.where(conditions).countDocuments();
                const qry = exercises_1.MExercises.aggregate([
                    { $match: conditions },
                    // get type of exercises
                    {
                        $lookup: {
                            from: 'types',
                            let: { qtype: { $toString: '$type' } },
                            as: 'types',
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$key', 'exercises_type'] }, { $eq: ['$code', '$$qtype'] }],
                                        },
                                    },
                                },
                                { $project: { _id: 0, typeName: '$name' } },
                            ],
                        },
                    },
                    // get total test
                    {
                        $lookup: {
                            from: 'exams',
                            // localField: '_id',
                            // foreignField: 'exercise',
                            as: 'exams',
                            let: { id: { $toString: '$_id' } },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$exercise', '$$id'] }, { $eq: ['$startBy', req.verify._id] }],
                                        },
                                    },
                                },
                                { $project: { _id: 1, result: 1 } },
                            ],
                        },
                    },
                    // get eligible
                    // {
                    //   $lookup: {
                    //     from: 'exams',
                    //     as: 'eligibleExams',
                    //     let: { id: { $toString: '$_id' } },
                    //     pipeline: [
                    //       {
                    //         $match: {
                    //           $expr: {
                    //             $and: [
                    //               { $eq: ['$exercise', '$$id'] },
                    //               { $eq: ['$startBy', req.verify._id] },
                    //               { $eq: ['$result', 1] },
                    //             ],
                    //           },
                    //         },
                    //       },
                    //       { $project: { _id: 1 } },
                    //     ],
                    //   },
                    // },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: [
                                    { $arrayElemAt: ['$types', 0] },
                                    // { $arrayElemAt: ['$eligibleExams', 0] },
                                    '$$ROOT',
                                ],
                            },
                        },
                    },
                    {
                        $addFields: {
                            numberLeft: { $subtract: ['$numberTest', { $size: '$exams' }] },
                        },
                    },
                    {
                        $project: {
                            types: 0,
                            users: 0,
                            questions: 0,
                        },
                    },
                    {
                        $sort: {
                            [req.query.sortBy || 'startAt']: -1,
                        },
                    },
                ]);
                const page = parseInt(req.query.page);
                const rowsPerPage = parseInt(req.query.rowsPerPage);
                if (page && rowsPerPage)
                    qry.skip((page - 1) * rowsPerPage).limit(rowsPerPage);
                const rs = yield qry.exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.getQuestions = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (!req.query.key)
                    return res.status(500).send('invalid');
                const exercise = yield exercises_1.MExercises.findById({ _id: req.query.key }, 'questions');
                if (!exercise)
                    return res.status(500).send('invalid');
                const conditions = {
                    // key: req.query.key,
                    _id: { $in: exercise.questions },
                };
                const countDocuments = yield questions_1.MQuestion.where(conditions).countDocuments();
                const qry = questions_1.MQuestion.aggregate([
                    { $match: conditions },
                    {
                        $addFields: {
                            correctLength: { $size: '$correct' },
                            answersSelect: null,
                        },
                    },
                    {
                        $project: {
                            types: 0,
                            correct: 0,
                            point: 0,
                        },
                    },
                    {
                        $sort: {
                            [req.query.sortBy || 'orders']: req.query.descending === 'true' ? -1 : 1,
                        },
                    },
                ]);
                const page = parseInt(req.query.page);
                const rowsPerPage = parseInt(req.query.rowsPerPage);
                if (page && rowsPerPage)
                    qry.skip((page - 1) * rowsPerPage).limit(rowsPerPage);
                const rs = yield qry.exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.getReport = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (!req.query.key)
                    return res.status(500).send('invalid');
                const exercise = yield exercises_1.MExercises.findById({ _id: req.query.key }, 'users');
                if (!exercise)
                    return res.status(500).send('invalid');
                // const users = await MUser.find({ username: { $in: exercise.users } } as any);
                // console.log(users);
                // return res.status(200).json([]);
                const conditions = { username: { $in: exercise.users } };
                const countDocuments = yield users_1.MUser.where(conditions).countDocuments();
                const qry = users_1.MUser.aggregate([
                    { $match: conditions },
                    {
                        $project: {
                            types: 0,
                        },
                    },
                    {
                        $lookup: {
                            from: 'exams',
                            as: 'exams',
                            let: { id: { $toString: '$_id' } },
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$startBy', '$$id'] }, { $eq: ['$exercise', req.query.key] }],
                                        },
                                    },
                                },
                                {
                                    $project: {
                                        _id: 0,
                                        startAt: 1,
                                        endAt: 1,
                                        totalQuestion: 1,
                                        totalCorrect: 1,
                                        totalWrong: 1,
                                        result: 1,
                                        flag: 1,
                                    },
                                },
                            ],
                        },
                    },
                    {
                        $project: {
                            _id: 0,
                            username: 1,
                            fullName: 1,
                            gender: 1,
                            avatar: 1,
                            address: 1,
                            dateBirth: 1,
                            email: 1,
                            personNumber: 1,
                            exams: 1,
                        },
                    },
                    {
                        $sort: {
                            [req.query.sortBy || 'username']: req.query.descending === 'true' ? -1 : 1,
                        },
                    },
                ]);
                const page = parseInt(req.query.page);
                const rowsPerPage = parseInt(req.query.rowsPerPage);
                if (page && rowsPerPage)
                    qry.skip((page - 1) * rowsPerPage).limit(rowsPerPage);
                const rs = yield qry.exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.post = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (!req.body || !Object.keys(req.body).length) {
                    return res.status(500).send('invalid');
                }
                const questions = yield questions_1.MQuestion.find({ key: req.body.exercise }).countDocuments();
                const data = new exams_1.MExams({
                    startAt: new Date(),
                    // endAt: ,
                    startBy: req.verify._id,
                    startIp: request_1.getIp(req),
                    // userAgent: getUserAgent(req),
                    exercise: req.body.exercise,
                    totalQuestion: questions,
                    selected: null,
                    // totalCorrect: { type: Number, default: 0 },
                    // totalWrong: { type: Number, default: 0 },
                    flag: 1,
                });
                data.save((e, rs) => {
                    if (e)
                        return res.status(500).send(e);
                    // Push logs
                    logger_1.default.set(req, this.path, rs._id, 'insert');
                    return res.status(200).json(rs);
                });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.put = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_1, _a;
            try {
                // if (!req.params.id) return res.status(500).send('Incorrect Id!')
                if (!req.body || !Object.keys(req.body).length)
                    return res.status(500).send('invalid');
                const exam = yield exams_1.MExams.findById(req.body._id);
                if (!exam)
                    return res.status(500).send('invalid');
                const exercise = yield exercises_1.MExercises.findById(exam.exercise);
                if (!exercise)
                    return res.status(500).send('invalid');
                const questions = yield questions_1.MQuestion.find({ key: exam.exercise });
                try {
                    for (var questions_2 = __asyncValues(questions), questions_2_1; questions_2_1 = yield questions_2.next(), !questions_2_1.done;) {
                        const e = questions_2_1.value;
                        const item = req.body.questions.find((x) => x._id.toString() === e._id.toString());
                        if (item) {
                            if (!Array.isArray(item.answers))
                                item.answers = [item.answers];
                            item.correct = e.correct;
                            if (item.answers.sort().toString() === e.correct.sort().toString()) {
                                exam.totalCorrect++;
                            }
                            else {
                                exam.totalWrong++;
                            }
                        }
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (questions_2_1 && !questions_2_1.done && (_a = questions_2.return)) yield _a.call(questions_2);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                exam.endAt = new Date();
                exam.questions = req.body.questions;
                exam.result = exam.totalCorrect >= exercise.eligible ? 1 : 0;
                exam.flag = 2;
                const rs = yield exams_1.MExams.updateOne({ _id: req.body._id }, {
                    $set: {
                        endAt: exam.endAt,
                        totalCorrect: exam.totalCorrect,
                        totalWrong: exam.totalWrong,
                        questions: exam.questions,
                        result: exam.result,
                        flag: exam.flag,
                    },
                });
                // Push logs
                logger_1.default.set(req, this.path, rs._id, 'update');
                if (!rs)
                    return res.status(500).send('invalid');
                return res.status(200).json(exam);
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.patch = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_2, _b;
            try {
                const rs = { success: [], error: [] };
                try {
                    for (var _c = __asyncValues(req.body._id), _d; _d = yield _c.next(), !_d.done;) {
                        const _id = _d.value;
                        const x = yield exams_1.MExams.findById(_id);
                        if (x) {
                            const _x = yield exams_1.MExams.updateOne({ _id }, { $set: { flag: x.flag === 1 ? 0 : 1 } });
                            if (_x.nModified) {
                                rs.success.push(_id);
                                // Push logs
                                logger_1.default.set(req, this.path, _id, x.flag === 1 ? 'lock' : 'unlock');
                            }
                            else
                                rs.error.push(_id);
                        }
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_d && !_d.done && (_b = _c.return)) yield _b.call(_c);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
                return res.status(203).json(rs);
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.delete = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (mongoose_1.Types.ObjectId.isValid(req.params._id)) {
                    exams_1.MExams.deleteOne({ _id: req.params._id }, (e) => {
                        if (e)
                            return res.status(500).send(e);
                        // Push logs
                        logger_1.default.set(req, this.path, req.params._id, 'delete');
                        return res.status(204).json(true);
                    });
                }
                else {
                    return res.status(500).send('invalid');
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
    }
}
exports.default = new ExamsController();
//# sourceMappingURL=exams.js.map