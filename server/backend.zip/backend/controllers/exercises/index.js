"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
const logger_1 = __importDefault(require("../../services/logger"));
const pagination_1 = __importDefault(require("../../utils/pagination"));
const mongoose_1 = require("mongoose");
const request_1 = require("../../utils/request");
const exercises_1 = require("../../models/exercises");
const questions_1 = require("../../models/questions");
class ExercisesController {
    constructor() {
        this.path = 'exercises';
        this.get = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                const conditions = {};
                if (req.query.filter) {
                    conditions.$text = { $search: req.query.filter };
                }
                conditions.flag = parseInt(req.query.flag.toString()) || 1;
                const countDocuments = yield exercises_1.MExercises.where(conditions).countDocuments();
                const rs = yield exercises_1.MExercises.aggregate([
                    { $match: conditions },
                    {
                        $lookup: {
                            from: 'types',
                            let: { qtype: { $toString: '$type' } },
                            as: 'types',
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$key', 'exercises_type'] }, { $eq: ['$code', '$$qtype'] }],
                                        },
                                    },
                                },
                                { $project: { _id: 0, typeName: '$name' } },
                            ],
                        },
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: [{ $arrayElemAt: ['$types', 0] }, '$$ROOT'],
                            },
                        },
                    },
                    {
                        $project: {
                            types: 0,
                        },
                    },
                ])
                    .skip((parseInt(req.query.page) - 1) * parseInt(req.query.rowsPerPage))
                    .limit(parseInt(req.query.rowsPerPage))
                    .sort({
                    [req.query.sortBy || 'orders']: req.query.descending === 'true' ? -1 : 1,
                }) // 1 ASC, -1 DESC
                    .exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.find = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (req.query._id) {
                    if (mongoose_1.Types.ObjectId.isValid(req.query._id)) {
                        exercises_1.MExercises.findById(req.query._id, (e, rs) => {
                            if (e)
                                return res.status(500).send(e);
                            return res.status(200).json(rs);
                        });
                    }
                    else {
                        return res.status(500).send('invalid');
                    }
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.exist = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                exercises_1.MExercises.findOne(req.query, (e, rs) => {
                    if (e)
                        return res.status(200).json(null);
                    return res.status(200).json(rs);
                });
            }
            catch (e) {
                return res.status(200).json(null);
            }
        });
        this.getAttr = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                exercises_1.MExercises.distinct(req.query.key ? 'attr.key' : 'attr.value', null, (e, rs) => {
                    if (e)
                        return res.status(500).send(e);
                    if (req.query.filter)
                        rs = rs.filter((x) => new RegExp(req.query.filter, 'i').test(x));
                    const countDocuments = rs.length;
                    if (req.query.page && req.query.rowsPerPage)
                        rs = pagination_1.default.get(rs, parseInt(req.query.page), parseInt(req.query.rowsPerPage));
                    return res.status(200).json({ rowsNumber: countDocuments, data: rs });
                });
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.post = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_1, _a;
            if (!req.body || Object.keys(req.body).length < 1) {
                return res.status(500).send('invalid');
            }
            const session = yield mongoose_1.startSession();
            session.startTransaction();
            try {
                // const x = await MExercises.findOne({ code: req.body.code });
                // if (x) return res.status(501).send('exist');
                const rs = { success: [], error: [] };
                const questions = req.body.questions;
                req.body.createdAt = new Date();
                req.body.createdBy = req.verify._id;
                req.body.createdIp = request_1.getIp(req);
                // console.log(req.body.createdIp);
                // req.body.userAgent = getUserAgent(req);
                req.body.startAt = moment_1.default(req.body.startAt, 'DD/MM/YYYY HH:mm:00');
                req.body.endAt = moment_1.default(req.body.endAt, 'DD/MM/YYYY HH:mm:00');
                req.body.totalQuestion = questions.length;
                req.body.questions = [];
                // Save Exercises
                const data = new exercises_1.MExercises(req.body);
                // data.validate()
                const dataSave = yield data.save();
                // Save Questions
                let index = 0;
                const questionsExercises = [];
                try {
                    for (var questions_2 = __asyncValues(questions), questions_2_1; questions_2_1 = yield questions_2.next(), !questions_2_1.done;) {
                        const e = questions_2_1.value;
                        index = index + 1;
                        e.key = dataSave._id;
                        const item = new questions_1.MQuestion(e);
                        const itemSave = yield item.save();
                        if (itemSave) {
                            rs.success.push(index);
                            questionsExercises.push(itemSave._id);
                        }
                        else
                            rs.error.push(index);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (questions_2_1 && !questions_2_1.done && (_a = questions_2.return)) yield _a.call(questions_2);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                yield exercises_1.MExercises.updateOne({ _id: dataSave._id }, {
                    $set: {
                        questions: questionsExercises,
                    },
                });
                // Push logs
                logger_1.default.set(req, this.path, dataSave._id, 'insert');
                return res.status(201).json({ data: dataSave, result: rs });
            }
            catch (e) {
                console.log(e);
                yield session.abortTransaction();
                session.endSession();
                return res.status(500).send({ error: e, ip: req.ip });
            }
        });
        this.put = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                // if (!req.params.id) return res.status(500).send('Incorrect Id!')
                if (!req.body || Object.keys(req.body).length < 1)
                    return res.status(500).send('invalid');
                if (mongoose_1.Types.ObjectId.isValid(req.body._id)) {
                    exercises_1.MExercises.updateOne({ _id: req.body._id }, {
                        $set: {
                            categories: req.body.categories,
                            kind: req.body.kind,
                            level: req.body.level,
                            point: req.body.point,
                            content: req.body.content,
                            answers: req.body.answers,
                            correct: req.body.correct,
                            tags: req.body.tags,
                            order: parseInt(req.body.order),
                            flag: parseInt(req.body.flag),
                        },
                    }, (e, rs) => {
                        // { multi: true, new: true },
                        if (e)
                            return res.status(500).send(e);
                        // Push logs
                        logger_1.default.set(req, this.path, rs._id, 'update');
                        return res.status(202).json(rs);
                    });
                }
                else {
                    return res.status(500).send('invalid');
                }
            }
            catch (e) {
                return res.status(500).send(e);
            }
        });
        this.patch = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_2, _b;
            try {
                const rs = { success: [], error: [] };
                try {
                    for (var _c = __asyncValues(req.body._id), _d; _d = yield _c.next(), !_d.done;) {
                        const _id = _d.value;
                        const x = yield exercises_1.MExercises.findById(_id);
                        if (x) {
                            const _x = yield exercises_1.MExercises.updateOne({ _id }, { $set: { flag: x.flag === 1 ? 0 : 1 } });
                            if (_x.nModified) {
                                rs.success.push(_id);
                                // Push logs
                                logger_1.default.set(req, this.path, _id, x.flag === 1 ? 'lock' : 'unlock');
                            }
                            else
                                rs.error.push(_id);
                        }
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_d && !_d.done && (_b = _c.return)) yield _b.call(_c);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
                return res.status(203).json(rs);
            }
            catch (e) {
                return res.status(500).send(e);
            }
        });
        this.delete = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (mongoose_1.Types.ObjectId.isValid(req.params._id)) {
                    exercises_1.MExercises.deleteOne({ _id: req.params._id }, (e) => {
                        if (e)
                            return res.status(500).send(e);
                        // Push logs
                        logger_1.default.set(req, this.path, req.params._id, 'delete');
                        return res.status(204).json(true);
                    });
                }
                else {
                    return res.status(500).send('invalid');
                }
            }
            catch (e) {
                return res.status(500).send(e);
            }
        });
    }
}
exports.default = new ExercisesController();
//# sourceMappingURL=index.js.map