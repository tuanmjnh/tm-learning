"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
const logger_1 = __importDefault(require("../../services/logger"));
const pagination_1 = __importDefault(require("../../utils/pagination"));
const mongoose_1 = require("mongoose");
const request_1 = require("../../utils/request");
const questions_1 = require("../../models/questions");
const import_1 = require("../../models/questions/import");
class QuestionsController {
    constructor() {
        this.path = 'questions';
        this.get = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                const conditions = { $and: [{ flag: req.query.flag ? req.query.flag : 1 }] };
                if (req.query.filter) {
                    conditions.$and.push({ content: { $search: req.query.filter } });
                }
                if (req.query.categories) {
                    conditions.$and.push({ categories: { $in: [req.query.categories] } });
                }
                if (!req.query.sortBy)
                    req.query.sortBy = 'orders';
                const countDocuments = yield questions_1.MQuestion.where(conditions).countDocuments();
                const rs = yield questions_1.MQuestion.aggregate([
                    {
                        $lookup: {
                            from: 'types',
                            let: { qkind: { $toString: '$kind' } },
                            as: 'kinds',
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$key', 'question_kind'] }, { $eq: ['$code', '$$qkind'] }],
                                        },
                                    },
                                },
                                { $project: { _id: 0, kindName: '$name' } },
                            ],
                        },
                    },
                    // { $unwind: '$kinds' }, // $unwind used for getting data in object or for one record only
                    {
                        $lookup: {
                            from: 'types',
                            let: { qlevel: { $toString: '$level' } },
                            as: 'levels',
                            pipeline: [
                                {
                                    $match: {
                                        $expr: {
                                            $and: [{ $eq: ['$key', 'question_level'] }, { $eq: ['$code', '$$qlevel'] }],
                                        },
                                    },
                                },
                                { $project: { _id: 0, levelName: '$name' } },
                            ],
                        },
                    },
                    {
                        $replaceRoot: {
                            newRoot: {
                                $mergeObjects: [
                                    { $arrayElemAt: ['$levels', 0] },
                                    { $arrayElemAt: ['$kinds', 0] },
                                    '$$ROOT',
                                ],
                            },
                        },
                    },
                    // { $unwind: '$levels' }, // $unwind used for getting data in object or for one record only
                    {
                        $project: {
                            kinds: 0,
                        },
                    },
                ])
                    .match(conditions)
                    .skip((parseInt(req.query.page) - 1) * parseInt(req.query.rowsPerPage))
                    .limit(parseInt(req.query.rowsPerPage))
                    .sort({
                    [req.query.sortBy || 'orders']: req.query.descending === 'true' ? -1 : 1,
                }) // 1 ASC, -1 DESC
                    .exec();
                return res.status(200).json({ rowsNumber: countDocuments, data: rs });
            }
            catch (e) {
                console.log(e);
                return res.status(500).send('invalid');
            }
        });
        this.find = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (req.query._id) {
                    if (mongoose_1.Types.ObjectId.isValid(req.query._id)) {
                        questions_1.MQuestion.findById(req.query._id, (e, rs) => {
                            if (e)
                                return res.status(500).send(e);
                            return res.status(200).json(rs);
                        });
                    }
                    else {
                        return res.status(500).send('invalid');
                    }
                }
                else if (req.query.key) {
                    questions_1.MQuestion.find({ key: req.query.key }, (e, rs) => {
                        if (e)
                            return res.status(500).send(e);
                        return res.status(200).json(rs);
                    });
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.exist = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                questions_1.MQuestion.findOne(req.query, (e, rs) => {
                    if (e)
                        return res.status(200).json(null);
                    return res.status(200).json(rs);
                });
            }
            catch (e) {
                return res.status(200).json(null);
            }
        });
        this.getAttr = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                questions_1.MQuestion.distinct(req.query.key ? 'attr.key' : 'attr.value', null, (e, rs) => {
                    if (e)
                        return res.status(500).send(e);
                    if (req.query.filter)
                        rs = rs.filter((x) => new RegExp(req.query.filter, 'i').test(x));
                    const countDocuments = rs.length;
                    if (req.query.page && req.query.rowsPerPage)
                        rs = pagination_1.default.get(rs, parseInt(req.query.page), parseInt(req.query.rowsPerPage));
                    return res.status(200).json({ rowsNumber: countDocuments, data: rs });
                });
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.post = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (!req.body || Object.keys(req.body).length < 1) {
                    return res.status(500).send('invalid');
                }
                // const x = await MQuestion.findOne({ code: req.body.code });
                // if (x) return res.status(501).send('exist');
                req.body.created = { at: new Date(), by: req.verify._id, ip: request_1.getIp(req) };
                const data = new questions_1.MQuestion(req.body);
                // data.validate()
                data.save((e, rs) => {
                    if (e)
                        return res.status(500).send(e);
                    // Push logs
                    logger_1.default.set(req, this.path, rs._id, 'insert');
                    return res.status(201).json(rs);
                });
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.import = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_1, _a;
            if (!req.body || !req.body.length) {
                return res.status(500).send('invalid');
            }
            const session = yield mongoose_1.startSession();
            session.startTransaction();
            try {
                const rs = { success: [], error: [] };
                let index = 0;
                const importData = new import_1.MQuestionImport({
                    code: parseInt(moment_1.default().format('YYYYMMDDHHmmssms')),
                    total: req.body.length,
                    createdAt: new Date(),
                    createdBy: req.verify._id,
                    createdIp: request_1.getIp(req),
                });
                const importSave = yield importData.save();
                try {
                    for (var _b = __asyncValues(req.body), _c; _c = yield _b.next(), !_c.done;) {
                        const e = _c.value;
                        index = index + 1;
                        e.key = importSave._id;
                        const item = new questions_1.MQuestion(e);
                        const itemSave = yield item.save();
                        if (itemSave)
                            rs.success.push(index);
                        else
                            rs.error.push(index);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) yield _a.call(_b);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                return res.status(201).json(rs);
            }
            catch (e) {
                console.log(e);
                yield session.abortTransaction();
                session.endSession();
                return res.status(500).send('invalid');
            }
        });
        this.put = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                // if (!req.params.id) return res.status(500).send('Incorrect Id!')
                if (!req.body || Object.keys(req.body).length < 1)
                    return res.status(500).send('invalid');
                if (mongoose_1.Types.ObjectId.isValid(req.body._id)) {
                    questions_1.MQuestion.updateOne({ _id: req.body._id }, {
                        $set: {
                            categories: req.body.categories,
                            kind: req.body.kind,
                            level: req.body.level,
                            point: req.body.point,
                            content: req.body.content,
                            answers: req.body.answers,
                            correct: req.body.correct,
                            tags: req.body.tags,
                            order: parseInt(req.body.order),
                            flag: parseInt(req.body.flag),
                        },
                    }, (e, rs) => {
                        // { multi: true, new: true },
                        if (e)
                            return res.status(500).send(e);
                        // Push logs
                        logger_1.default.set(req, this.path, rs._id, 'update');
                        return res.status(202).json(rs);
                    });
                }
                else {
                    return res.status(500).send('invalid');
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.patch = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            var e_2, _d;
            try {
                const rs = { success: [], error: [] };
                try {
                    for (var _e = __asyncValues(req.body._id), _f; _f = yield _e.next(), !_f.done;) {
                        const _id = _f.value;
                        const x = yield questions_1.MQuestion.findById(_id);
                        if (x) {
                            const _x = yield questions_1.MQuestion.updateOne({ _id }, { $set: { flag: x.flag === 1 ? 0 : 1 } });
                            if (_x.nModified) {
                                rs.success.push(_id);
                                // Push logs
                                logger_1.default.set(req, this.path, _id, x.flag === 1 ? 'lock' : 'unlock');
                            }
                            else
                                rs.error.push(_id);
                        }
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_f && !_f.done && (_d = _e.return)) yield _d.call(_e);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
                return res.status(203).json(rs);
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
        this.delete = (req, res, next) => __awaiter(this, void 0, void 0, function* () {
            try {
                if (mongoose_1.Types.ObjectId.isValid(req.params._id)) {
                    questions_1.MQuestion.deleteOne({ _id: req.params._id }, (e) => {
                        if (e)
                            return res.status(500).send(e);
                        // Push logs
                        logger_1.default.set(req, this.path, req.params._id, 'delete');
                        return res.status(204).json(true);
                    });
                }
                else {
                    return res.status(500).send('invalid');
                }
            }
            catch (e) {
                return res.status(500).send('invalid');
            }
        });
    }
}
exports.default = new QuestionsController();
//# sourceMappingURL=index.js.map